import React from 'react'
import PropTypes from 'prop-types'

function Reports(props) {
  return (
    <div>Reports</div>
  )
}

Reports.propTypes = {}

export default Reports;
